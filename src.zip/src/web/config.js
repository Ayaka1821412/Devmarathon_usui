const config = {
  apiUrl: 'http://localhost:5440'
};

export default config;